// import logo from './logo.svg';
import './App.css';
import { Grocery } from './components/Grocery';

function App() {
  return (
    <div className="App">
      <Grocery></Grocery>
    </div>
  );
}

export default App;
